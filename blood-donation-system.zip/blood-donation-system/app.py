from flask import Flask, request, render_template, redirect, url_for
import csv
import os

app = Flask(__name__)

# Path for the CSV file
csv_file_path = 'registrations.csv'

# Ensure the 'uploads' directory exists for file storage
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Allow only specific file types (for ID proof)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}

# Configure Flask to handle file uploads
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # Max file size (16MB)

# Ensure the CSV file exists with headers
if not os.path.isfile(csv_file_path):
    with open(csv_file_path, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Name", "Role", "Date of Birth", "Blood Group", "Gender", "Phone", "Email", "Address", "ID Proof"])

# Helper function to check allowed file extensions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        # Perform any necessary login validation
        # Redirect to index.html on successful login
        return render_template('index.html')
    return render_template('index.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/registration', methods=['GET', 'POST'])
def registration():
    if request.method == 'POST':
        # Collect form data
        name = request.form['name']
        role = request.form['role']
        blood_group = request.form['group']
        gender = request.form['gender']
        phone = request.form['phone']
        email = request.form['email']
        address = request.form['address']

        # Check if ID file is provided
        id_proof = request.files.get('ID')  # Use .get() to avoid KeyError
        id_filename = None
        if id_proof and allowed_file(id_proof.filename):
            filename = os.path.join(app.config['UPLOAD_FOLDER'], id_proof.filename)
            id_proof.save(filename)
            id_filename = id_proof.filename

        # Save registration data to CSV
        with open(csv_file_path, 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([name, role, blood_group, gender, phone, email, address, id_filename])

        # Redirect to a success page
        return render_template('registration_success.html', name=name)

    return render_template('registration.html')

if __name__ == '__main__':
    app.run(debug=True)
