const express = require("express");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { createObjectCsvWriter } = require("csv-writer");
const fs = require("fs");
const dotenv = require("dotenv");

dotenv.config();

const app = express();
app.use(bodyParser.json());

// CSV file setup
const csvWriter = createObjectCsvWriter({
  path: "C:\Users\abhin\OneDrive\Documents\bloodDonation", 
  header: [
    { id: "name", title: "Name" },
    { id: "bloodGroup", title: "Blood Group" },
    { id: "contact", title: "Contact" },
    { id: "location", title: "Location" },
  ],
});

const verifyToken = (req, res, next) => {
  const token = req.body.token || req.headers["authorization"];

  if (!token) {
    return res.status(403).send("Token is required");
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).send("Invalid token");
    }
    req.user = decoded;
    next();
  });
};

// Route to handle form submission
app.post("/register", async (req, res) => {
    const { role, name, dob, bloodGroup, gender, phone, email, address, idProof } = req.body;
  
    if (!role || !name || !dob || !bloodGroup || !gender || !phone || !email || !address || !idProof) {
      return res.status(400).json({ message: "All fields are required" });
    }
  
    // Prepare the data to be written to the CSV
    const record = {
      role,
      name,
      dob,
      bloodGroup,
      gender,
      phone,
      email,
      address,
      idProof: req.files ? req.files.ID.name : "No ID uploaded", // Handle file upload
    };
  
    // Check if the file already exists, create a new one if not
    if (!fs.existsSync("form_data.csv")) {
      // Create CSV with header if file doesn't exist
      await csvWriter.writeRecords([record]); // Write the first record with header
    } else {
      // Append the data to existing CSV
      await csvWriter.writeRecords([record]);
    }
  
    // Respond back to the client
    res.json({ message: "Registration successful" });
  });

// User login route
app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  // For demo purposes, we're skipping DB validation. 
  // You'd compare passwords from your DB here
  const mockPassword = "hashedPassword"; // Replace this with DB check

  const isPasswordValid = await bcrypt.compare(password, mockPassword);
  if (!isPasswordValid) {
    return res.status(400).json({ message: "Invalid email or password" });
  }

  const token = jwt.sign({ email }, process.env.JWT_SECRET, { expiresIn: "1h" });
  res.json({ token });
});

// Form submission route
app.post("/submit", verifyToken, async (req, res) => {
  const { name, bloodGroup, contact, location } = req.body.formData;

  if (!name || !bloodGroup || !contact || !location) {
    return res.status(400).json({ message: "Missing required form data" });
  }

  // Prepare the data to be written to the CSV
  const record = { name, bloodGroup, contact, location };

  // Check if file exists, create new one if not
  if (!fs.existsSync("form_data.csv")) {
    // Create a CSV file with headers if it doesn't exist
    await csvWriter.writeRecords([record]); // Create CSV file
  } else {
    // Append data to existing CSV
    await csvWriter.writeRecords([record]);
  }

  res.json({ message: "Form submitted successfully" });
});

// Server setup
const port = process.env.PORT || 5000;
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
